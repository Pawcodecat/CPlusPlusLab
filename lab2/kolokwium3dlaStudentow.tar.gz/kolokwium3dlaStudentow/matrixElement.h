#ifndef MATRIX_ELEMENT
#define MATRIX_ELEMENT

typedef int MatrixElement;

#endif // MATRIX_ELEMENT
