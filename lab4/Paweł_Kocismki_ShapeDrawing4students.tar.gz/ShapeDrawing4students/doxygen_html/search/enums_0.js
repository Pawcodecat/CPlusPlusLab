var searchData=
[
  ['shapeoperation_139',['ShapeOperation',['../namespace_shapes.html#a7ad0d120716b06293701e9472420bdde',1,'Shapes']]]
];
