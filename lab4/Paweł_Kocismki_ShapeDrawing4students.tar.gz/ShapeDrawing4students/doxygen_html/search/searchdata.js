var indexSectionsWithContent =
{
  0: "_abcdefgilmoprstv~",
  1: "crs",
  2: "ams",
  3: "acmprs",
  4: "cdegimoprstv~",
  5: "_abdflmst",
  6: "p",
  7: "s",
  8: "dis"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerations",
  8: "Enumerator"
};

