var searchData=
[
  ['mail_31',['MAIL',['../namespace_students_info.html#ad7dddaebb2a74ecaadf135306b72c78b',1,'StudentsInfo']]],
  ['main_32',['main',['../main_8cpp.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main.cpp']]],
  ['main_2ecpp_33',['main.cpp',['../main_8cpp.html',1,'']]],
  ['memorymanagement_2ecpp_34',['memoryManagement.cpp',['../memory_management_8cpp.html',1,'']]],
  ['memorymanagement_2eh_35',['memoryManagement.h',['../memory_management_8h.html',1,'']]],
  ['myownmemorymanagement_36',['MyOwnMemoryManagement',['../namespace_my_own_memory_management.html',1,'']]]
];
