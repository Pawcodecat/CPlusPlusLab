var searchData=
[
  ['myownmemorymanagement_77',['MyOwnMemoryManagement',['../namespace_my_own_memory_management.html',1,'']]]
];
