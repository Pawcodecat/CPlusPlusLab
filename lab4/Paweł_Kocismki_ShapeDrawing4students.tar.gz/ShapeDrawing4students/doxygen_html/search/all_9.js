var searchData=
[
  ['lowerleftpoint_30',['lowerLeftPoint',['../class_shapes_1_1_shape.html#a489004b4eff239c83e11f78813f417ee',1,'Shapes::Shape']]]
];
