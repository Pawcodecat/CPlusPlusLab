var searchData=
[
  ['setx_47',['setX',['../class_shapes_1_1_shape.html#ac7d7cc0bfd9d5a3f32df8ed486c70f8f',1,'Shapes::Shape']]],
  ['sety_48',['setY',['../class_shapes_1_1_shape.html#a30e54933494c73b59fc93a9c430de18d',1,'Shapes::Shape']]],
  ['shape_49',['Shape',['../class_shapes_1_1_shape.html',1,'Shapes::Shape'],['../class_shapes_1_1_shape.html#a366a9d56ffa18bb8d9f36b05cf4880b0',1,'Shapes::Shape::Shape()']]],
  ['shape_2eh_50',['shape.h',['../shape_8h.html',1,'']]],
  ['shapecomposite_51',['ShapeComposite',['../class_shapes_1_1_shape_composite.html',1,'Shapes::ShapeComposite'],['../class_shapes_1_1_shape_composite.html#a43a15119af1adad6b1858bfb188391fb',1,'Shapes::ShapeComposite::ShapeComposite()']]],
  ['shapecomposite_2eh_52',['shapecomposite.h',['../shapecomposite_8h.html',1,'']]],
  ['shapeoperation_53',['ShapeOperation',['../namespace_shapes.html#a7ad0d120716b06293701e9472420bdde',1,'Shapes']]],
  ['shapes_54',['Shapes',['../namespace_shapes.html',1,'']]],
  ['shapestests_2ecpp_55',['ShapesTests.cpp',['../_shapes_tests_8cpp.html',1,'']]],
  ['stage_56',['Stage',['../class_stage.html',1,'Stage'],['../class_stage.html#ad0ae4a85e52056eca1b9646902155bcc',1,'Stage::Stage()']]],
  ['stage_2eh_57',['stage.h',['../stage_8h.html',1,'']]],
  ['studentsinfo_58',['StudentsInfo',['../namespace_students_info.html',1,'']]],
  ['sum_59',['SUM',['../namespace_shapes.html#a7ad0d120716b06293701e9472420bddea6970bdc2201030b9c03fbdcf3973858a',1,'Shapes']]],
  ['surname_60',['SURNAME',['../namespace_students_info.html#af9868f1d365a6204fa0c594240886099',1,'StudentsInfo']]]
];
