var searchData=
[
  ['operator_20delete_5b_5d_110',['operator delete[]',['../memory_management_8cpp.html#a2682309c6add153a8a0c11ebcf1e71b7',1,'operator delete[](void *memory2remove) noexcept:&#160;memoryManagement.cpp'],['../memory_management_8cpp.html#a9618091831ee3ce365a052f7f5e65142',1,'operator delete[](void *memory2remove, size_t) noexcept:&#160;memoryManagement.cpp'],['../memory_management_8h.html#a2682309c6add153a8a0c11ebcf1e71b7',1,'operator delete[](void *memory2remove) noexcept:&#160;memoryManagement.cpp'],['../memory_management_8h.html#a9618091831ee3ce365a052f7f5e65142',1,'operator delete[](void *memory2remove, size_t) noexcept:&#160;memoryManagement.cpp']]],
  ['operator_20new_5b_5d_111',['operator new[]',['../memory_management_8cpp.html#a63ce4f64887b9307317aee5baae6b18f',1,'operator new[](size_t size):&#160;memoryManagement.cpp'],['../memory_management_8h.html#a63ce4f64887b9307317aee5baae6b18f',1,'operator new[](size_t size):&#160;memoryManagement.cpp']]]
];
