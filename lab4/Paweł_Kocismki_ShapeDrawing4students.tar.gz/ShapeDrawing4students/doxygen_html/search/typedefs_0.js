var searchData=
[
  ['point_138',['Point',['../namespace_shapes.html#abd877f253c178671a4ae622da4ab5abe',1,'Shapes']]]
];
