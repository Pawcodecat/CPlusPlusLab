var searchData=
[
  ['main_2ecpp_84',['main.cpp',['../main_8cpp.html',1,'']]],
  ['memorymanagement_2ecpp_85',['memoryManagement.cpp',['../memory_management_8cpp.html',1,'']]],
  ['memorymanagement_2eh_86',['memoryManagement.h',['../memory_management_8h.html',1,'']]]
];
