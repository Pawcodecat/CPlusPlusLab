var searchData=
[
  ['validatefirstname_121',['validateFirstname',['../namespace_students_info.html#a9ae344559f9e3afba47d36c94aae9853',1,'StudentsInfo']]],
  ['validatemail_122',['validateMail',['../namespace_students_info.html#a07e3ac7ae97c3f4f8771aec53cc57986',1,'StudentsInfo']]],
  ['validatestudentbookid_123',['validateStudentBookId',['../namespace_students_info.html#a5f15e3dff24a4552f35ea9b79a3d24f5',1,'StudentsInfo']]],
  ['validatestudentsinfo_124',['validateStudentsInfo',['../namespace_students_info.html#af02a8b711571c13cc3df27c66d3a0415',1,'StudentsInfo']]],
  ['validatesurname_125',['validateSurname',['../namespace_students_info.html#af2e763673d7e477557a822cf435e5856',1,'StudentsInfo']]]
];
