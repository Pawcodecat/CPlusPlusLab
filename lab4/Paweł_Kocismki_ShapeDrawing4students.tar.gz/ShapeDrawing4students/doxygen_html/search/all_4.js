var searchData=
[
  ['deletions_15',['deletions',['../namespace_my_own_memory_management.html#a10032a8d05e12a6fcdd9e27cc7475b02',1,'MyOwnMemoryManagement']]],
  ['difference_16',['DIFFERENCE',['../namespace_shapes.html#a7ad0d120716b06293701e9472420bddeac61a4b4c2c0a00de4d7cef87a7abc4b1',1,'Shapes']]],
  ['drawindstageimplemented_17',['drawindStageImplemented',['../_shapes_tests_8cpp.html#a035b464fda2a3db56add66decd80b541',1,'ShapesTests.cpp']]],
  ['drawshape2stream_18',['drawShape2Stream',['../class_stage.html#adf11c2cb435816f9abc0134c328fcaa2',1,'Stage']]]
];
