var searchData=
[
  ['sum_142',['SUM',['../namespace_shapes.html#a7ad0d120716b06293701e9472420bddea6970bdc2201030b9c03fbdcf3973858a',1,'Shapes']]]
];
